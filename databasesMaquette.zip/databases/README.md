La base `MusiquePT2` peut être récupérée depuis les liens ci-dessous (autour de `150Mo`).

Il y a 2 morceaux :
- '.mdf' est le fichier des données : https://box.iut.u-bordeaux.fr/f/e357bbe27d9748148fe7/?dl=1
- '.ldf' est le fichier du journal de transaction : https://box.iut.u-bordeaux.fr/f/8e4746ad003a4d81b5dc/?dl=1

Pour attacher la base, il suffit de suivre la procédure suivante :
https://docs.microsoft.com/fr-fr/sql/relational-databases/databases/attach-a-database?view=sql-server-ver15 .

***Remarque*** : il peut y avoir un problème de droits d’accès sous Windows, facilement contournable en déposant la base dans l’espace `C:\Utilisateurs\Public\`.
